import framework.project2.ConstExprResult;
import generated.SplcBaseVisitor;
import generated.SplcParser;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ConstExprVisitor extends SplcBaseVisitor<Integer> {

    private final List<ConstExprResult> results = new ArrayList<>();

    public final List<ConstExprResult> getResults() {
        return Collections.unmodifiableList(results);
    }

    protected final void addResult(String expression, int value) {
        results.add(new ConstExprResult(expression, value));
    }

    @Override
    public Integer visitLocalVarDef(SplcParser.LocalVarDefContext ctx) {
        SplcParser.ExpressionContext initializer = ctx.expression();
        if (initializer != null) {
            Integer value = visit(initializer);
            if (value != null) {
                addResult(initializer.getText(), value);
            }
        }
        return null;
    }

    /** A null value means the entire expression is not a constexpr. */
    @Override
    public Integer visitExpression(SplcParser.ExpressionContext ctx) {
        if (ctx.Number() != null) {
            return Integer.parseInt(ctx.Number().getText());
        }

        int operands = ctx.expression().size();
        if (operands == 1) {
            if (ctx.LPAREN() != null) {
                return visit(ctx.expression(0));
            }
            if (ctx.PLUS() != null || ctx.MINUS() != null) {
                Integer value = visit(ctx.expression(0));
                if (value == null) {
                    return null;
                }
                return ctx.MINUS() != null ? -value : value;
            }
            return null;
        }

        // Reject every other expression form before evaluating its children.
        if (operands != 2 || (ctx.PLUS() == null && ctx.MINUS() == null
                && ctx.STAR() == null && ctx.DIV() == null && ctx.MOD() == null)) {
            return null;
        }

        Integer left = visit(ctx.expression(0));
        if (left == null) {
            return null;
        }
        Integer right = visit(ctx.expression(1));
        if (right == null) {
            return null;
        }

        if (ctx.PLUS() != null) {
            return left + right;
        }
        if (ctx.MINUS() != null) {
            return left - right;
        }
        if (ctx.STAR() != null) {
            return left * right;
        }
        if (ctx.DIV() != null) {
            return left / right;
        }
        return left % right;
    }
}
